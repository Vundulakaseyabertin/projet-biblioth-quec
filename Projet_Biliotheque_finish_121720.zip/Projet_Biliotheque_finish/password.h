#ifndef PASSWORD_H
#define PASSWORD_H

void sauvegarder_mot_de_passe();
void connexion();

#endif
